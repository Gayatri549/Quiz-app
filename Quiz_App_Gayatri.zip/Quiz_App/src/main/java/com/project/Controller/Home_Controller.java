package com.project.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.Model.Admin;
import com.project.Model.Student;
import com.project.Repositary.Admin_repo;
import com.project.Repositary.Student_repo;


@Controller
public class Home_Controller {
	@Autowired
	Student_repo stu_repo;
	@Autowired
	Admin_repo adm_repo;
	/*    -----------------Landing Page-----------------------*/
	@RequestMapping("/")
	public String Home() {
		return "Home.jsp";
	}
	/*    ---------------Student Sign Up-----------------------*/
	@RequestMapping("/signup")
	public String signup(@ModelAttribute Student s1,Model model) {
		stu_repo.save(s1);
		 if(s1==null) {
			 
			  model.addAttribute("message", "Invalid Information!please fill the all fields of form.");
			  return "success.jsp";
			  
			  }
		return "Student_login.jsp";
	}
	/*    ---------------Student Login-----------------------*/
	@RequestMapping("/Quiz_home")
	public String Quiz_home(@RequestParam String email,@RequestParam String password,HttpSession hs,Model model) {
		Student ob=stu_repo.findByEmail(email);
		if(ob!=null && ob.getEmail().equalsIgnoreCase(email) && ob.getPassword().equals(password))
		{	
			 hs.setAttribute("Username",ob.getName());
		     return "Quiz_home.jsp";
		}
		else
		{
			 model.addAttribute("message", "Check your email and password.");
			  return "success.jsp";
			  
		}
	}
	/*    ---------------Admin Sign Up-----------------------*/
	@RequestMapping("/admin_signup")
	public String admin_signup(@ModelAttribute Admin a1) {
		adm_repo.save(a1);
		return "Admin_Login.jsp";
	}
	@RequestMapping("/admin_login")
	public String admin_login(@RequestParam String email,@RequestParam String password) {
		Admin ob=adm_repo.findByEmail(email);
		if(ob!=null && ob.getEmail().equalsIgnoreCase(email) && ob.getPassword().equals(password))
		return "Main_admin.jsp";
		else
			return "fail.jsp";
	}
}

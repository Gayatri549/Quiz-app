package com.project.Controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.Model.Questions;
import com.project.Model.QuizeResult;
import com.project.Repositary.Question_repo;
import com.project.Repositary.QuizResult_repo;

@Controller
public class Student_Controller {
	@Autowired
	Question_repo que_repo;
	@Autowired
	QuizResult_repo qr_repo;
	static int total=0;
	@RequestMapping("/display_Quiz")
	public String display_Quiz(Model m) {
		List<Questions> l1=que_repo.findAll();
		
		
		Collections.shuffle(l1);
		  m.addAttribute("data",l1);
		 
		return "student/Datafetch_student.jsp";
	}
	
	 @RequestMapping("favicon.ico")
	 public void returnNoFavicon() {
	     // Do nothing, or return a 204 No Content
	 }

	 /*main code*/
	 @PostMapping("/result123")
	 public String submitAnswers(@RequestParam(value="answer", required=false) String[] answers,
	                             @RequestParam(value="correctAnswer", required=false) String[] correctAnswers,Model model,@RequestParam String username) {
		    System.out.println(Arrays.toString(answers));
		    System.out.println(Arrays.toString(correctAnswers));
		    if (answers == null || answers.length == 0) {
		         System.out.println("No answers received");
		     } else {
		         System.out.println("User Answers: " + Arrays.toString(answers));
		     }

		     if (correctAnswers == null || correctAnswers.length == 0) {
		         System.out.println("No correct answers received");
		     } else {
		         System.out.println("Correct Answers: " + Arrays.toString(correctAnswers));
		     }
		    int score=0;
		    for (int i = 0; i < answers.length; i++) {
	            if (answers[i].equalsIgnoreCase(correctAnswers[i])) {
	                score++;
	            }
	        }
		    QuizeResult qr=new  QuizeResult() ;
		    qr.setScore(score);
		    qr.setUserName(username);
		    qr_repo.save(qr);
		    model.addAttribute("score", score);
	     return "student/Result.jsp";
	 }
	
	
}
package com.project.Controller;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.Model.Questions;

import com.project.Model.QuizeResult;
import com.project.Repositary.Question_repo;
import com.project.Repositary.QuizResult_repo;



@Controller
public class Admin_controller {
	@Autowired
	Question_repo que_repo;
	
	@Autowired
	QuizResult_repo qui_rp;
	/*-----------Admin add question here---------*/
  @RequestMapping("/add_question")
  public String add_question(@ModelAttribute Questions q1,Model model) {
	 if(q1!=null) {
	  que_repo.save(q1);
	  model.addAttribute("message", "Question added successfully!");
	  
	  }else {
		  model.addAttribute("message", "Question cannot be empty!");
		  
		  }
	  
	  return "success.jsp"; 
  }
  
  /*----------fectch all data from database------*/
  @RequestMapping("/alldata")
  public String alldata(Model m) {
	  List<Questions> l1=que_repo.findAll();
	  m.addAttribute("data",l1);
	  System.out.println(l1);
      return "DataFetch.jsp";
  }
  
  @RequestMapping("/Delete/{id}")
  public String Delete(@PathVariable int id) {
	que_repo.deleteById(id);
	 
      return "redirect:/alldata";
  }
  
  @RequestMapping("/{id}")
  public String update(@PathVariable int id,Model m1) {
	Questions q1=que_repo.findById(id).orElse(null);
	m1.addAttribute("data_up",q1);
	 
      return "Edit_data.jsp";
  }
  @RequestMapping("/edit_update/{id}")
  public String edit_update(@PathVariable int id,@ModelAttribute Questions q) {
	  Questions q1=que_repo.findById(id).orElse(null);
	  if(q1!=null)
	  {
		  q1.setQuestion(q.getQuestion());
		  q1.setOp1(q.getOp1());
		  q1.setOp2(q.getOp2());
		  q1.setOp3(q.getOp3());
		  q1.setOp4(q.getOp4());
		  q1.setAnswer(q.getAnswer());
		  q1.setMarks(q.getMarks());
		  que_repo.save(q1);
	  }
	 
	  return "redirect:/alldata";
  }
  @RequestMapping("/view_admin_result")
  public String view_result(Model m) {
	  List<QuizeResult> l1=qui_rp.findAll();
	  Set<QuizeResult> uniqueResults = new LinkedHashSet<>(l1);
	  m.addAttribute("data",uniqueResults);
	 
      return "DataFetch_Result.jsp";
	     
	  }

}

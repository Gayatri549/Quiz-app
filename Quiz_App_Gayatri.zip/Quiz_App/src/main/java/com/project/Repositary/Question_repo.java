package com.project.Repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Model.Questions;

public interface Question_repo extends JpaRepository<Questions,Integer>{
  List<Questions> findAll();
}

package com.project.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Model.Admin;

public interface Admin_repo  extends JpaRepository<Admin,Integer>{
  Admin findByEmail(String email);
}

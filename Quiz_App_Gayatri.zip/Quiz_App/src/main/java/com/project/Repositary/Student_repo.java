package com.project.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Model.Student;

public interface Student_repo extends JpaRepository<Student, Integer> {
  Student findByEmail(String email);
}

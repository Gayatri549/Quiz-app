package com.project.Repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Model.QuizeResult;

public interface QuizResult_repo extends JpaRepository<QuizeResult, Integer> {

}
